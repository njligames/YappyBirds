









local ParamInfo = {}

ParamInfo =
{
	Dog = 
	{
 MaxSpeed = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 MaxForce = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(), 
 DazedTime = 5,
 CapturedHeight = 20,
	},
	Bird =
	{
 chubiBird =
 {
 MaxSpeed = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 MaxForce = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 AttackTime = 6,
 StealSpeed = .1,
 },
 garuBird =
 {
 MaxSpeed = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 MaxForce = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 AttackTime = 5,
 StealSpeed = .2,
 },
 momiBird =
 {
 MaxSpeed = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 MaxForce = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 AttackTime = 4,
 StealSpeed = .3,
 },
 puffyBird =
 {
 MaxSpeed = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 MaxForce = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 AttackTime = 3,
 StealSpeed = .4,
 },
 weboBird =
 {
 MaxSpeed = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 MaxForce = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 AttackTime = 2,
 StealSpeed = .5,
 },
 zuruBird =
 {
 MaxSpeed = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 MaxForce = njli.World.getInstance():getWorldLuaVirtualMachine():getMaxNumber(),
 AttackTime = 1,
 StealSpeed = .6,
 },
 DieY = -50,
	},
	Projectile = 
	{
 WaterBalloon =
 {
 Azimuth = 10,
 Magnitude = 25,

 },
 DieY = -50,
	},
}

return ParamInfo
