
njli.World.getInstance():startSocket(192, 168, 1, 4, 2223)


function WorldRenderHUD()
end